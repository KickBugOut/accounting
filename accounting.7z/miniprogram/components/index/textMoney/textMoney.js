Component({
  properties: {
    text: String,
    money: String
  }
})