Component({
  properties: {
    type: String,
    color: {
      type: String,
      value: '#69c0ff'
    }
  }
})