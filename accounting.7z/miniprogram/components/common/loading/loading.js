Component({
  properties: {
    type: {
      type: String,
      value: 'line'
    },
    width: {
      type: String,
      value: '100'
    },
    height: {
      type: String,
      value: '100'
    },
    color: {
      type: String,
      value: '#40a9ff'
    }
  }
})