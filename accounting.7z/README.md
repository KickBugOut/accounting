# accounting
云开发打造，用于记账的微信小程序 - 言己账本

# 项目二维码 / opening qr code
![启动二维码](./mdImg/open-qrcode.jpg)

# 项目首页展示 / index page display
![项目首页](https://github.com/WellFine/accounting/blob/master/mdImg/index-page.jpg)

# 项目入账页展示 / add page display
![项目首页](./mdImg/add-page.jpg)

# 项目详情页展示 / detail page display
![项目首页](./mdImg/detail-page.jpg)
